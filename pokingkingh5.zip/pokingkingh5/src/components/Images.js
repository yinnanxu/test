const images = {
    default_img: 'http://deshpro.b0.upaiyun.com/deshpro_public/default_img.png',
    empty_img: '/images/empty_ticket.png',
    iphoneload:'/images/iphoneload.png',
    androidload:'/images/androidload.png',
    safari:'/images/safari.png',
    pukewang:'/images/pukewang.png',
    point:'/images/point.png',
    bottom:'/images/bottom.png',
    left:'/images/left.png',
    right:'/images/right.png',
    bg:'/images/bg.jpeg',
    NLH12:'/images/1K_2K_NLH.png',
    NLH24:'/images/2K_4K_NLH.png',
    NLH510:'/images/50_100_NLH.png',
    NLH1020:'/images/100_200_NLH.png',
    NLH36:'/images/300_600_NLH.png',
    PLO5010:'/images/50_100_PLO.png',
    PLO1020:'/images/100_200_PLO.png',
    AVAILABLE:'/images/AVAILABLE.png',
    bg_03:'/images/bg_03.png'


}

export default images